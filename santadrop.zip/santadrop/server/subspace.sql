create database SUBSPACE;
create user 'h2o'@'localhost' identified by 'dontpeeinthepool';
grant all on SUBSPACE.* to 'h2o'@'localhost';

