var ws = require('nodejs-websocket');
var fs = require('fs');
var mysql = require('mysql');
var readline = require('readline');

require('./common.js');

global.THREE = require('three');
global.player = require('./player.js');
global.game = require('./game.js');
global.ship = require('./ship.js');
require('./simulatedObject.js');

var GameServer = function(opts){
	
	// global objects
	this.pl = global.player;
	this.g = global.game;
	
	this.connectToDB = function(){
		// create mysql db connections
		var db = global.db = mysql.createConnection({
		  host     : 'localhost',
		  user     : 'h2o',
		  password : 'dontpeeinthepool',
		  database : 'SUBSPACE'
		});
		
		// connect
		db.connect(function(err){
			if(err){
				if(db.connected){
					console.error("Disconnected from MySQL: ", err,"\nReconnecting in 2 sec");
					setTimeout(global.server.connectToDB, 2000);
				} else {
					console.error("Failed to connect to MySQL: ", err);
					global.server.shutDown();
				}
				db.connected = false;
				global.db = db = null;
			} else {
				db.connected = true;
				console.log("Connected to MySQL");
			}
		});
		
		db.on('error', function(err) {
		    console.log('MySQL error: ', err);
		    if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
		      global.server.connectToDB();                // lost due to either server restart, or a
		    } else {                                      // connnection idle timeout (the wait_timeout
		      throw err;                                  // server variable configures this)
		    }
		});
	};
	
	return this;
};

GameServer.prototype = {
	version: "1.0",
	constructor: GameServer,
	
	// client connected
	onClientConnected: function(conn){
		var self = conn.server.gameServer;
		console.log("Client connected: " + conn.socket.remoteAddress);
		
		// add events
		conn.on('text', 	self.onClientText);
		conn.on('error', 	self.onClientError);
		conn.on('close', 	self.onClientDisconnected);
	},
	
	// client disconnected
	onClientDisconnected: function (code, reason) {
		if(this.user) (global.player.logout.bind(this))();
       	console.log("Connection to " + this.socket.remoteAddress + " closed: " + code + " " + reason);
	},
	
	// client error
	onClientError: function(err){
		console.log("Connection to " + this.socket.remoteAddress + " error: " + err);
	},
	
	// client data receive
	onClientText: function(str){
		var self = this.server.gameServer;
		
		// convert data from JSON
		var json = null;
	    try {
		    json = JSON.parse(str);
		} catch(e){
			console.log("Receive error: %j", e);
			return;
		}
		
		// remote call
	    // {rc: [OBJECT.FUNCNAME, <opt.arguments>]}
	    // {rc: [OBJECT.FUNCNAME, <opt.arguments>], rid:RESPONSEID }
	    if(json.hasOwnProperty('rc')){
		    var funcName = json['rc'][0];
		    var parts = funcName.split('.');
		    var object = self;
		    if(parts.length > 1){
			    object = self.hasOwnProperty(parts[0]) ? self[parts[0]] : undefined;
			    funcName = parts[1];
		    }
		    // rid is response ID for callbacks on clients
		    var rid = json.hasOwnProperty('rid') ? json.rid : undefined;
		    // call function with connection as 'this', and arguments array
		    if(object != undefined && object[funcName] && typeof(object[funcName]) == 'function'){
			    var func = object[funcName];
			    json.rc.splice(0,1); // remove first arg
			    // construct callback function
			    var callback;
			    if(rid) { 
				    callback = function(retValue){
				    	this.sendText(JSON.stringify({rid:rid, val:retValue}));
			    	}.bind(this);
			    	json.rc.push(callback);
			    }
			    // call func, this = connection
			    var retVal;
			    try {
			    	retVal = func.apply(this, json.rc);
			    } catch(e){
			    	console.log("RC Error: ", e);
			    }
			    // if retVal was returned, and rid was set, respond immediately
			    // delayed responder just needs to call callback(retValue)
			    if(retVal != undefined && rid){
				    callback(retVal);
			    }
		    } else {
			    console.log("Invalid call ",json);
		    }
	    } else {
		 	//todo - other protocols
		 	console.log("Unknown protocol: %j", json);
		}
	},
	
	// server started
	onServerListening: function(){
		console.log("Server is listening");
	},
	
	onServerClose: function(){
		console.log("Server is shut down");
	},
	
	onServerError: function(errObj){
		console.log("Server error: %j", errObj);
	},
	
	// start server
	start: function(port){
		console.log("Starting server on port "+port);

		this.connectToDB();

		// create websocket server
		this.server = ws.createServer(this.onClientConnected);
		this.server.gameServer = this;
		
		// events
		this.server.on('listening', 	this.onServerListening);
		this.server.on('close', 		this.onServerClose);
		this.server.on('error',	 		this.onServerError);
		
		// start listening
		this.server.listen(port);
		
		// start game
		global.game.start();
	},	
	
	shutDown: function(){
		this.server.socket.close();
	},
	
	// send update on object array
	upd:function(connection, serverTime, objectArray){
		var numObj = objectArray.length;
		var sum = new Array(numObj);
		for(var i = 0; i < numObj; i++){
			sum[i] = objectArray[i].getUpdateJSON();
		}
		var sendText = "{\"rc\":[\"game.updateObjects\"," + serverTime + ",[" + sum.join(',') + "]]}";
		connection.sendText(sendText);
	},
	
	//remote call
	rc:function(connection, funcName /*, optional parameters */) {
		var args = Array.prototype.slice.call(arguments);
		args.splice(0, 1);
		connection.sendText(JSON.stringify({rc:args}));
	}
};

// process traps
function handleSignal(){
	console.log("Signal caught");
	global.game.shutdown();
};
process.on("SIGINT", handleSignal);
//process.on("SIGHUP", handleSignal);
process.on("SIGQUIT", handleSignal);
process.on("SIGABRT", handleSignal);
process.on("SIGTERM", handleSignal);

if(process.stdin._handle && process.stdout._type == 'tty'){
	var prompt = readline.createInterface(process.stdin, process.stdout);
	prompt.setPrompt('Javascript> ');
	prompt.on('line', function(line) {
		try{ 
			var res = eval(line);
			console.log(res);
		} catch(e){
			console.log(e);
		}
	    prompt.prompt();
	}).on('close', handleSignal);
	global.prompt = prompt;
}

// start server
var server = global.server = new GameServer();
server.start(9998);
