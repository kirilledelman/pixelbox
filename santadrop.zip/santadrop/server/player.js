var THREE = global.THREE;

// test add an object
exports.pew = function(dist){
	var obj, offs;
	obj = new global.SimulatedObject({owner:this.user.ID, type:'test', debugLabel:'F', _timeToLive:5.0, elev:this.pawn.elev, lat:this.pawn.lat, long:this.pawn.long});
	obj.ry = this.pawn.ry;
	obj.df = this.pawn.df + 10;
	global.game.addObject(obj);
	
	obj = new global.SimulatedObject({owner:this.user.ID, type:'test', debugLabel:'R', _timeToLive:5.0, elev:this.pawn.elev, lat:this.pawn.lat, long:this.pawn.long});
	obj.ry = this.pawn.ry;
	obj.dr = this.pawn.dr + 10;
	global.game.addObject(obj);

}

exports.poles = function(){
	var obj = new global.SimulatedObject({owner:this.user.ID, type:'test', debugLabel:'N', _timeToLive:120.0, elev:this.pawn.elev });
	obj.lat = Math.PI * 0.5;
	obj.long = 0;
	global.game.addObject(obj);
	
	for(var l = -Math.PI; l < Math.PI; l+= Math.PI * 0.1){
		obj = new global.SimulatedObject({owner:this.user.ID, type:'test', debugLabel:'.', _timeToLive:60.0, elev:this.pawn.elev });
		obj.lat = Math.PI * 0.5 - 0.02;
		obj.long = l;
		global.game.addObject(obj);
	}
	
};

exports.applyPos = function(lat,long,ry,df){
	this.pawn.lat = parseFloat(lat);
	this.pawn.long = parseFloat(long);
	this.pawn.ry = parseFloat(ry);
	this.pawn.df = parseFloat(df);
	
	this.pawn.makeDirty();	
}


//
function possess(objID){
	var obj = global.game.objectsByName[objID];
	if(!obj || obj.owner != this.user.ID){
		console.log("Player "+this.user.USERNAME+" couldn't possess object "+objID);
		return false;
	}
	
	// possess
	if(this.pawn){
		this.pawn._possessedBy = null;
	}
	this.pawn = obj;
	this.pawn._possessedBy = this;
	return true;
}
exports.possess = possess;

// recreate player assets for the first time
function reset(){
	if(!this.user) return;
	console.log("Resetting player "+this.user.USERNAME);
	
	// delete all player-owned assets
	global.db.query("DELETE FROM OBJECTS WHERE OWNER=?", [this.user.ID]);
	
	// add ship for Connection(this)
	global.ship.createDefaultShip.apply(this);
}
exports.reset = reset; // comment out


// get objects owned by player
function getAssets(callback){
	//todo
	global.db.query("SELECT * FROM OBJECTS WHERE OWNER=?", [this.user.ID], function(err, res){
		var arr = [];
		var numRes = res.length;
		for(var i = 0; i < numRes; i++){
			arr.push(JSON.parse(res[i].DATA));
		}
		callback(arr);
	});
}
exports.getAssets = getAssets;

// create a new player
function createNewPlayer(username, emailAddr, hashedPass, callback){
	username = (username || '').toString();
	emailAddr = (emailAddr || '').toString();
	hashedPass = (hashedPass || '').toString();
	
	// validate username
	if(username.length < 2) return {error:"Username is too short (min 3 chars)", field: 'username' };
	// pass
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(!(re).test(emailAddr)) return {error:"Invalid email address", field: 'email' };

	// see if already registered
	global.db.query("SELECT ID FROM USERS WHERE USERNAME = ? LIMIT 1", [username], function(err, res){
		if(err) console.error(err);
		
		var retValue = {success:1};
		
		// already exists
		if(res.length) {
			retValue = {error:"Username already exists", field: 'username' };
		// create new player
		} else {
			// insert credentials
			global.db.query("INSERT INTO USERS (USERNAME,EMAIL,PASS,CREATED) VALUES (?,?,?,NOW())", [username, emailAddr, hashedPass]);
		}
		
		callback(retValue);
	});
}
exports.createNewPlayer = createNewPlayer;

function login(username, hashedPass, callback){
	username = (username || '').toString();
	hashedPass = (hashedPass || '').toString();
	var connection = this;
	
	// check if a user is already logged in
	for(var i = 0; i < this.server.connections.length; i++){
		var conn = this.server.connections[i];
		if(conn.user && conn.user.USERNAME == username){
			return {error: "User already logged in elsewhere"};			
		}
	}
	
	global.db.query("SELECT * FROM USERS WHERE USERNAME=? AND PASS=? LIMIT 1", [username, hashedPass], function(err, res){
		if(res.length){
			connection.user = res[0];
			
			console.log("Hello " + res[0].USERNAME + " @ " + connection.socket.remoteAddress + ", last seen: "+connection.user.LAST_SEEN);
			
			// if this is the very first time
			if(connection.user.LAST_SEEN === null) reset.apply(connection);
			
			// update record
			global.db.query("UPDATE USERS SET LAST_SEEN=NOW() WHERE ID=? LIMIT 1", [res[0].ID]);
			
			// tell game
			global.game.playerLoggedIn(connection);
			
			// notify that log in was successful
			callback({success:{username:username, email: connection.user.EMAIL, last_seen:connection.user.LAST_SEEN}});
		} else {
			callback({error:"Invalid username or password"});
		}
	});
}
exports.login = login;


function logout(){
	console.log("Goodbye " + this.user.USERNAME + " @ " + this.socket.remoteAddress);
	// tell game
	global.game.playerLoggedOut(this);

	// update last seen
	global.db.query("UPDATE USERS SET LAST_SEEN=NOW() WHERE ID=? LIMIT 1", [this.user.ID]);
	delete this.user;
}
exports.logout = logout;

