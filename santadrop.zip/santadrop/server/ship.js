function createDefaultShip(){
	// this is connection, this.user is user record
	
	var ship = new global.SimulatedObject({owner:this.user.ID, type:'ship', debugLabel:this.user.USERNAME});
	global.game.addObject(ship);
	ship.save();
}
exports.createDefaultShip = createDefaultShip;