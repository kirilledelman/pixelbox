/* generates unique ID
	identical to THREE.Math.generateUUID */
global.UUID = function () {
		var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split( '' );
		var uuid = new Array( 36 );
		var rnd = 0, r;

		return function () {

			for ( var i = 0; i < 36; i ++ ) {

				if ( i == 8 || i == 13 || i == 18 || i == 23 ) {

					uuid[ i ] = '-';

				} else if ( i == 14 ) {

					uuid[ i ] = '4';

				} else {

					if ( rnd <= 0x02 ) rnd = 0x2000000 + ( Math.random() * 0x1000000 ) | 0;
					r = rnd & 0xf;
					rnd = rnd >> 4;
					uuid[ i ] = chars[ ( i == 19 ) ? ( r & 0x3 ) | 0x8 : r ];

				}
			}
			return uuid.join( '' );
		};
}();

global.sphericalDistance = function(lat1,long1,lat2,long2){
	var cl1 = Math.cos(lat1); 
	var x1 = cl1 * Math.cos(long1);
	var y1 = cl1 * Math.sin(long1);
	var z1 = Math.sin(lat1);

	var cl2 = Math.cos(lat2); 
	var x2 = cl2 * Math.cos(long2);
	var y2 = cl2 * Math.sin(long2);
	var z2 = Math.sin(lat2);

	var xx = x2 - x1;
	var yy = y2 - y1;
	var zz = z2 - z1;
	
	var dist = Math.sqrt(xx*xx + yy*yy + zz*zz);
	return dist;
};

/* returns distance between two points on a globe in radians */
global.harvesineDistance = function(lat1,long1,lat2,long2) {
    //spherical law of cos - acos(SIN(lat1)*SIN(lat2)+COS(lat1)*COS(lat2)*COS(lon2-lon1))
	/*var dist = Math.acos(Math.cos((lat1)) * Math.cos((lat2)) *
             Math.cos((long1) - (long2)) +
             Math.sin((lat1)) * Math.sin((lat2)));*/
	var dlat = (lat2-lat1);
	var dlong = (long2-long1);
	var a = Math.sin(dlat*0.5) * Math.sin(dlat*0.5) +
	        Math.cos(lat1) * Math.cos(lat2) *
	        Math.sin(dlong*0.5) * Math.sin(dlong*0.5);
	var dist = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return dist;
};

/* 	convert x,y to lat,long
	latitude must be != Math.PI/2 */
global.xy2ll = function(x,y,lat,long){
	var cl = Math.cos(lat);
	return {
		long: cl == 0 ? 0 : (x / (global.game.config.planetRadius * cl)),
		lat: y / global.game.config.planetRadius	
	};
}

/* convert lat, long to xy */
global.ll2xy = function(lat, long, origLat, origLong) {
    var xx,yy,ct,st;
    
    ct = (long - origLong);
    ct = Math.atan2(Math.sin(ct),Math.cos(ct));
    xx = ct * global.game.config.planetRadius * Math.cos(lat); //METERS_DEGLON(origLat);
    
    st = (lat - origLat);
    st = Math.atan2(Math.sin(st),Math.cos(st));
	yy = st * global.game.config.planetRadius; //METERS_DEGLAT(origLong);

    return { x: xx, y: yy };
}
