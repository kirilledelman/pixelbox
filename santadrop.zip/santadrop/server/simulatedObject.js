/*

	forwardVelocity
	rightVelocity
	upVelocity
	
	based on rx,ry,rz - add a vector _rotation for calculation

*/

var THREE = global.THREE;

var positionValueNames = ['lat','long','elev'];
var velocityValueNames = ['df','dr','de','drx','dry','drz'];
var rotationValueNames = ['rx','ry','rz'];

function SimulatedObject(init){
	// copy props from init
	for(var prop in init){
		this[prop] = init[prop];
	}
	
	// add default/missing fields
	if(this['uuid'] == undefined) this.uuid = global.UUID();
	if(this['owner'] == undefined) this.owner = 0;
	if(this['type'] == undefined) this.type = null;
	
	if(this['lat'] == undefined) this.lat = 0; // position
	if(this['long'] == undefined) this.long = 0;
	if(this['elev'] == undefined) this.elev = 0;
	
	if(this['df'] == undefined) this.df = 0; // velocity
	if(this['dr'] == undefined) this.dr = 0; 
	if(this['de'] == undefined) this.de = 0; 
	
	if(this['parent'] == undefined) this.parent = null;
	
	if(this['rx'] == undefined) this.rx = 0; // rotation
	if(this['ry'] == undefined) this.ry = 0;
	if(this['rz'] == undefined) this.rz = 0;

	if(this['drx'] == undefined) this.drx = 0; // rotational vel
	if(this['dry'] == undefined) this.dry = 0;
	if(this['drz'] == undefined) this.drz = 0;

	
	// dirty flags
	this._dirty = this._positionDirty = this._rotationDirty = this._velocityDirty = true;
	this._prevPositionValues = [0,0,0];
	this._prevVelocityValues = [0,0,0,0,0,0];
	this._prevRotationValues = [0,0,0];

	// relevance tracking
	this._relevanceCount = 0;
	
	// think frequency
	this._nextTick = 0.0;
	this._tickFrequency = 0.1;
}

SimulatedObject.prototype = {
	constructor:SimulatedObject,
	
	/* object tick function
		ticks happen at max(this._tickFrequency, game.config.tickRate) 
		object is responsible for updating its position and any other props
		after tick(dt) returns, _dirty flag determines whether this object will be considered for sending network updates
	*/
	tick:function(dt){
		this._dirty = false;
		
		this._applyVelocity(dt);
		
		if(this._timeToLive){
			var ttl = this._timeToLive - dt;
			if(ttl <= 0){
				global.game.removeObject(this);
			} else {
				this._timeToLive = ttl;
			}
		}
		
		// combine dirty values into _dirty - checked by game loop
		this._dirty = this._dirty || this._rotationDirty || this._positionDirty;
	},
	
	_tempVector1: new THREE.Vector3(),
	_tempVector2: new THREE.Vector3(),
	_tempQuaternion: new THREE.Quaternion(),
	_upVector: new THREE.Vector3(0,1,0),
	_rightVector: new THREE.Vector3(1,0,0),
	_forwardVector: new THREE.Vector3(0,0,1),
		
	/* applies velocity to position */
	_applyVelocity:function(dt){
		// update rotation
		this.rx += this.drx * dt;
		this.ry += this.dry * dt;
		this.rz += this.drz * dt;
		this._rotationDirty = (this.rx != this._prevRotationValues[0] ||
								this.ry != this._prevRotationValues[1] ||
								this.rz != this._prevRotationValues[2]);
		if(this._rotationDirty) this._prevRotationValues = [this.rx,this.ry,this.rz];
	
		// update position
		// lat/long to xy
		var orig = global.ll2xy(this.lat, this.long, 0, 0);
		// setup directional rotation
		this._tempQuaternion.setFromAxisAngle(this._upVector, this.ry);
		// apply directional rotation to forward
		this._tempVector1.copy(this._forwardVector).applyQuaternion(this._tempQuaternion).multiplyScalar(this.df * dt);
		// apply directional rotation to right
		this._tempVector2.copy(this._rightVector).applyQuaternion(this._tempQuaternion).multiplyScalar(this.dr * dt);
		// add these vectors to position and convert back to lat,long
		orig.x += this._tempVector1.x + this._tempVector2.x;
		orig.y += this._tempVector1.z + this._tempVector2.z;
		var npos = global.xy2ll(orig.x, orig.y, this.lat, this.long);
		
		this.lat = npos.lat;
		this.long = npos.long;
		this.elev += this.de * dt;
		
		// wrap around lat
		if(this.lat >= Math.PI * 0.5) {
			this.lat = Math.PI * 0.5 - this.lat;
			this.dlat *= -1;
			if(this.long < 0) this.long += Math.PI;
			else this.long -= Math.PI;			
		} else if(this.lat <= -Math.PI * 0.5) {
			this.lat = -Math.PI - this.lat;
			this.dlat *= -1;
			if(this.long < 0) this.long += Math.PI;
			else this.long -= Math.PI;			
		}
		
		// wrap around long
		if(this.long >= Math.PI){
			this.long = (this.long - Math.PI) - Math.PI;
		} else if(this.long <= -Math.PI){
			this.long = Math.PI + (this.long + Math.PI);
		}
		
		// update position and velocity dirty flag
		this._positionDirty = (this.lat != this._prevPositionValues[0] || 
								this.long != this._prevPositionValues[1] ||
								this.elev != this._prevPositionValues[2]);
		if(this._positionDirty) this._prevPositionValues = [this.lat,this.long,this.elev];
		this._velocityDirty = (this.df != this._prevVelocityValues[0] || 
								this.dr != this._prevVelocityValues[1] ||
								this.de != this._prevVelocityValues[2] ||
								this.drx != this._prevVelocityValues[3] ||
								this.dry != this._prevVelocityValues[4] ||
								this.drz != this._prevVelocityValues[5]);
		if(this._velocityDirty) this._prevVelocityValues = [this.df,this.dr,this.de,this.drx,this.dry,this.drz];
	},
	
	/* start moving towards targLat / targLong / elev with speed */
	applySpeedTowards:function(speed, targLat, targLong, elev){
		// todo
	},
	
	/* set all dirty flags
		when first added to player's relevant set */
	makeDirty:function(){
		this._prevPositionValues = new Array(3);
		this._prevVelocityValues = new Array(3);
		this._prevRotationValues = new Array(3);
		this._dirty = this._positionDirty = this._rotationDirty = this._velocityDirty = true;
	},
	
	/* notification for when this object was added to conn's relevantObjects */
	becameRelevantTo:function(conn){
		this._relevanceCount++;
		console.log(this.uuid + " became relevant to "+conn.user.USERNAME);
	},

	/* notification for when this object was removed from conn's relevantObjects */
	becameIrrelevantTo:function(conn){
		this._relevanceCount--;
		console.log(this.uuid + " lost relevance to "+conn.user.USERNAME
		+", distance = "+(global.game.config.planetRadius * global.harvesineDistance(this.lat, this.long, conn.pawn.lat, conn.pawn.long)));
	},
	
	/* returns true if this object should be
		inluded in other's relevant set */
	isRelevantTo:function(conn){
		var other = conn.pawn;
		var dist = global.game.config.planetRadius * global.harvesineDistance(this.lat, this.long, other.lat, other.long);
		return (dist <= global.game.config.objectRelevanceDistance);
	},
	
	/* returns json to be sent during an update
		implement additional _dirty flags minimize data */		
	getUpdateJSON:function(){
		var rval = JSON.stringify(this, function(key, val){
			// don't send properties beginning with _
			if(key.substr(0, 1) == '_') return undefined;
			
			// positionDirty check
			if(positionValueNames.indexOf(key) >= 0 && !this._positionDirty) return undefined;

			// velocityDirty check
			if(velocityValueNames.indexOf(key) >= 0 && !this._velocityDirty) return undefined;
			
			// rotationDirty check
			if(rotationValueNames.indexOf(key) >= 0 && !this._rotationDirty) return undefined;
			
			return val;
		}.bind(this));
		
		return rval;
	},
	
	/* save state of this object to the database */
	save:function(onComplete){
		var loc = "GEOMFROMTEXT('POINT("+this.lat+" "+this.long+")')";
		var q;
		if(!this.id){
			q = "INSERT INTO OBJECTS (LOCATION,ELEVATION,TYPE,OWNER,DATA) VALUES ("+loc+",?,?,?,?)";
		} else {
			q = "UPDATE OBJECTS SET LOCATION="+loc+", ELEVATION=?, TYPE=?, OWNER=?, DATA=? WHERE ID="+this.id+" LIMIT 1";
		}
		var self = this;
		var dataString = JSON.stringify(this, function(key,val){
			if(key.substr(0,1) == '_') return undefined; // skip properties starting with _
			return val;
		});
		global.db.query(q, [this.elev,this.type,this.owner,dataString], function(err,res){
			if(err) {
				console.log("Error saving object: ",err);
			} else if(!self.id){
				self.id = res.insertId;
			}
			if(onComplete) onComplete();
		});
	},
	
	/* called when an object is about to be permanently destroyed */
	destroyed:function(){
		if(this.id){
			global.db.query("DELETE FROM OBJECTS WHERE ID=? LIMIT 1", [this.id]);
		}
	}	
	
};

global.SimulatedObject = SimulatedObject;