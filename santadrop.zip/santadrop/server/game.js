var __ = require('underscore');

/* Flow:
	upon log in, player calls player.getAssets
	one of the assets will be of type 'ship'
	player will call player.posess(objID) -> player.pawn = object
	
	each N seconds for each player, server determines which objects are relevant based on a radius
	player will receive updates about relevant objects
	player will receive notifications when an object is destroyed or removed from relevant set
	
	
*/
function Game(){
	
	this.objects = [];
	this.objectsByName = {};
	
	this.createQueue = [];
	this.deleteQueue = [];
	
	this.globalTime = 0;
	
	// move the following to configuration
	this.config = { 
		tickRate: 0.5,
		secondsPerDay:60,//300, // fime min day
		planetRadius:10000,
		objectRelevanceDistance: 1000,
		gameName:"Planet of the wetness"
	};
}

Game.prototype = {
	constructor: Game,
	
	/* main tick loop */
	tick: function(){
		// update clock
		var newDate = new Date();
		var newTime = newDate.getTime() * 0.001;
		var dt = newTime - this.globalTime;
		this.globalTime = newTime;
		
		// get currently connected players
		var conns = global.server.server.connections.concat();
		var numClients = conns.length;

		// create objects
		var queue = this.createQueue.concat();
		var numObj = queue.length;
		for(var i = 0; i < numObj; i++){
			var obj = queue[i];
			this.objects.push(obj);
		}
		this.createQueue = __.difference(queue, this.createQueue);

		// simulate objects
		numObj = this.objects.length;
		for(var i = 0; i < numObj; i++){
			var obj = this.objects[i];

			// tick object
			obj._nextTick += dt;
			if(obj._nextTick >= obj._tickFrequency){
				obj.tick(obj._nextTick);
				obj._nextTick = 0;
			}
			
			// update relevance
			for(var j = 0; j < numClients; j++){
				var conn = conns[j];
				// player is logged in and possesses a pawn
				if(conn.user && conn.pawn){
					var wasRelevant = (conn.relevantObjects[obj.uuid] != undefined);
					var isRelevant = (obj == conn.pawn) || ((!obj._destroying) && obj.isRelevantTo(conn));
					// relevance changed
					if(wasRelevant != isRelevant){
						if(wasRelevant){
							conn.irrelevantObjectsIDs.push(obj.uuid);
							delete conn.relevantObjects[obj.uuid];
							obj.becameIrrelevantTo(conn);
						} else {
							obj.makeDirty(); // makes all flags dirty
							conn.relevantObjects[obj.uuid] = obj;
							obj.becameRelevantTo(conn);
						}
					}
				}
			}		
		}

		// send updates to each player about relevant objects that have changed
		for(var j = 0; j < numClients; j++){
			var conn = conns[j];
			if(conn.user && conn.pawn){
				var updates = [];
				// add relevant, _dirty objects to updates to send
				for(var oid in conn.relevantObjects){
					var obj = conn.relevantObjects[oid];
					// relevant object for this player
					if(obj._dirty) updates.push(obj);
				}
				// send updates
				if(updates.length){
					global.server.upd(conn, this.globalTime, updates);
				}
				// send object removal
				if(conn.irrelevantObjectsIDs.length){
					global.server.rc(conn, 'game.removeObjects', conn.irrelevantObjectsIDs);
					// clear irrelevant set
					conn.irrelevantObjectsIDs.length = 0;
				}
			}
		}
		
		// delete destroyed objects
		queue = this.deleteQueue.concat();
		numObj = queue.length;
		for(var i = 0; i < numObj; i++){
			var obj = queue[i];
			var index = this.objects.indexOf(obj);
			if(index > 0){ this.objects.splice(index, 1); }
			delete this.objectsByName[obj.uuid];
			obj.destroyed();			
		}
		this.deleteQueue = __.difference(queue,this.deleteQueue);
	},

	
	/* 	add object to createQueue
		will add to world on next tick */
	addObject:function(simulatedObj){
		// skip if already there
		if(this.objectsByName[simulatedObj.uuid]) return;
		this.objectsByName[simulatedObj.uuid] = simulatedObj;
		this.createQueue.push(simulatedObj);
	},
	
	/* 	add object to deleteQueue
		will delete from world on next tick */
	removeObject:function(simulatedObj){
		if(simulatedObj._destroying) return;
		simulatedObj._destroying = true;
		this.deleteQueue.push(simulatedObj);
	},	

	/* called after player authenticates
		conn.user is current player's database record */
	playerLoggedIn:function(conn){
		// init connection
		conn.relevantObjects = { };
		conn.irrelevantObjectsIDs = [];
	},
	
	/* player logs out, or connection has been severed */
	playerLoggedOut:function(conn){
		// clean up
		
		// notify relevant set that player is leaving
		for(var uuid in conn.relevantObjects){
			conn.relevantObjects[uuid].becameIrrelevantTo(conn);
		}
		conn.relevantObjects = {};
		
		// todo - park the ship
	},

	/* client/server clock synch callback */
	syncClock:function(clientTime){
		var t = (new Date()).getTime();
		return {serverTime: t, difference: (t - clientTime)};
	},

	/* returns server's config object */
	getConfig:function(){ return global.game.config; },

	
	/* starts the server
		loads world objects from database
		starts tick loop */
	start:function(){
		this.globalTime = (new Date()).getTime() * 0.001;
		
		// add all objects
		global.db.query("SELECT * FROM OBJECTS", function(err, res){
			var numRestored = 0;
			for(var i = 0; i < res.length; i++){
				try {
					var data = JSON.parse(res[i].DATA);
					var so = new global.SimulatedObject(data);
					so.id = res[i].ID;
					global.game.addObject(so);
					numRestored++;
				} catch(err){
					console.log("Failed to restore object: ",res[i],"\n",err);
				}
			}
			console.log("Game started with "+numRestored+" objects, "+(res.length - numRestored)+" failed");
			
			// start server tick loop
			setInterval(global.game.tick.bind(global.game), global.game.config.tickRate * 1000.0);
			
			// show prompt
			if(global.prompt) global.prompt.prompt();
		});	
	},
	
	/* shut down the server
		save objects to database and exit */		
	shutdown:function(){
		// todo - save game state, time of day etc ?
		
		// persist all objects
		var filteredObjects = __.filter(this.objects, function(obj){ return (obj.id != undefined)});
		var numObj = filteredObjects.length;
		console.log("Shutting down\nSaving game state ("+numObj+" objects)");
		for(var i = 0; i < numObj; i++){
			var lastOne = (i == numObj - 1);
			var obj = filteredObjects[i];
			if(lastOne) obj.save(function(){ console.log("Shutdown complete"); process.exit(); });
			else obj.save();
		}
		if(!numObj){ 
			console.log("Shutdown complete");
			process.exit(); 
		}
	}
};

module.exports = new Game();