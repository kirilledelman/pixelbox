#import <UIKit/UIKit.h>

@interface UIWebView (clean)

- (void) cleanForDealloc;

@end
