#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <iAd/iAd.h>

@interface ViewController : UIViewController <UIWebViewDelegate>

@property (strong, nonatomic) NSMutableDictionary* sfx;
@property (strong, nonatomic) UIWebView *webView;

@property (weak, nonatomic) AVAudioPlayer* currentlyLooping;
@property (nonatomic) float loopingSoundTargetVol;
@property (nonatomic) float loopingSoundTargetVolStep;
@property (nonatomic) BOOL fadingIn;
@property (nonatomic) BOOL fadingOut;

-(void)appActiveChanged:(BOOL)active;

@end

