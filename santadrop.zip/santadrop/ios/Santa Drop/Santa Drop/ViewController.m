#import "ViewController.h"
#import "UIWebView+Clean.h"
#import <sys/utsname.h> // import it in your header or implementation file.

@interface ViewController ()

@property(nonatomic, copy) NSString* deviceType;

@end

#pragma mark - init

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0 green:34/255.0 blue:74/255.0 alpha:1.0];
    
    [self createWebView];
}

-(void)createWebView{
    // device
    struct utsname systemInfo;
    uname(&systemInfo);
    self.deviceType = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    // create webview
    CGFloat scaling = 2.0;
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, ceilf(self.view.bounds.size.width / scaling), ceilf(self.view.bounds.size.height / scaling))];
    _webView.layer.magnificationFilter = kCAFilterNearest;
    _webView.layer.minificationFilter = kCAFilterNearest;
    _webView.layer.shouldRasterize = true;
    _webView.transform = CGAffineTransformMakeScale(scaling, scaling);
    _webView.multipleTouchEnabled = false;
    _webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _webView.scrollView.showsHorizontalScrollIndicator = _webView.scrollView.showsVerticalScrollIndicator = false;
    _webView.center = CGPointMake(self.view.bounds.size.width * 0.5, self.view.bounds.size.height * 0.5);
    _webView.delegate = self;
    _webView.scrollView.bounces = false;
    _webView.alpha = 0;
    [self.view addSubview:_webView];
    
    // first load
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    if(![defaults objectForKey:@"firstRun"]){
        NSLog(@"First run");
        BOOL isOlderDevice = [self.deviceType containsString:@"iPad2"] || [self.deviceType containsString:@"iPad3"] || [self.deviceType containsString:@"iPod4"] || [self.deviceType containsString:@"iPhone4"] || [self.deviceType containsString:@"iPhone3"];
        [defaults setObject:@"0" forKey:@"firstRun"];
        [defaults setObject:@"true" forKey:@"music"];
        [defaults setObject:(isOlderDevice ? @"false" : @"true") forKey:@"shadows"];
    }
    
    // load content
    NSString *indexPath = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];
    NSURLRequest *req = [[NSURLRequest alloc] initWithURL:[NSURL fileURLWithPath:indexPath]];
    [_webView loadRequest:req];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)prefersStatusBarHidden{ return true; }

-(void)appActiveChanged:(BOOL)active{
    if(!active)[self.webView stringByEvaluatingJavaScriptFromString:@"pause();"];
}

#pragma mark - interface

-(void)javascriptCall:(NSDictionary*)params {
    NSMutableDictionary* retVal = nil;
    
    // dispatch call here
    NSString* str, *val;
    id arr;
    
    // getPref:[prefname1, prefname2...] -> { prefname1: value, prefname2: value }
    if((arr = [params objectForKey:@"getPref"])){
        if(![arr isKindOfClass:[NSArray class]]){
            arr = @[ arr ];
        }
        retVal = [NSMutableDictionary dictionary];
        for(NSString* pref in arr){
            val = [[NSUserDefaults standardUserDefaults] objectForKey:pref];
            [retVal setObject:(val ? val : [NSNull null]) forKey:pref];
        }
        
    // setPref:prefname, value:newValue
    } else if((str = [params objectForKey:@"setPref"])){
        [[NSUserDefaults standardUserDefaults] setObject:[params objectForKey:@"value"] forKey:str];
        [[NSUserDefaults standardUserDefaults] synchronize];
    
    // console.log
    } else if((arr = [params objectForKey:@"NSLog"])){
        NSLog(@">> %@", [((NSArray*)arr) componentsJoinedByString:@" "]);
    } else if((arr = [params objectForKey:@"userInteraction"])){
        _webView.userInteractionEnabled = ([arr integerValue] != 0);
    
    // playSound:sfx
    } else if((str = [params objectForKey:@"playSound"])){
        float vol = ([params objectForKey:@"volume"] && [params objectForKey:@"volume"] != [NSNull null]) ? [[params objectForKey:@"volume"] floatValue] : 1.0;
        float del = ([params objectForKey:@"delay"] && [params objectForKey:@"delay"] != [NSNull null]) ? [[params objectForKey:@"delay"] floatValue] : 0;
        [self playSound:str volume:vol delay:del];
    // loopSound:sfx
    } else if((str = [params objectForKey:@"loopSound"])){
        float vol = ([params objectForKey:@"volume"] && [params objectForKey:@"volume"] != [NSNull null]) ? [[params objectForKey:@"volume"] floatValue] : 1.0;
        [self loopSound:str volume:vol];
    // show ad
    } else if((str = [params objectForKey:@"showAd"])){
        [self showAd];
    }

    // call callback with retVal
    if(retVal){
        NSError *error;
        NSData *jsonData = retVal ? [NSJSONSerialization dataWithJSONObject:retVal options:0 error:&error] : nil;
        if (jsonData) {
            [_webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"ios.executeCallback(\"%@\",%@);",
                                                            [params objectForKey:@"callbackId"], [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding]]];
        } else {
            [_webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"ios.executeCallback(\"%@\",null);", [params objectForKey:@"callbackId"]]];
        }
    }
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    if(navigationType == UIWebViewNavigationTypeOther){
        NSArray* frags = [request.URL.absoluteString componentsSeparatedByString:@"#"];
        if(frags.count == 2){
            NSString* decoded = (__bridge NSString *) CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL,(__bridge CFStringRef) [frags objectAtIndex:1], CFSTR(""), kCFStringEncodingUTF8);
            NSData *jsonData = [decoded dataUsingEncoding:NSUTF8StringEncoding];
            NSError* error = nil;
            NSDictionary* object = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
            if (error) { NSLog(@"Error parsing URL fragment as JSON: %@\n%@", error, decoded); }
            else {
                //NSLog(@"Javascript passed string:%@\n\nobject: %@", decoded, object);
                [self javascriptCall:object];
            }
        }
    }
    return true;
}

-(void)webViewDidStartLoad:(UIWebView *)webView{
    [_webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"window.olderDevice=%@; window.deviceType=\"%@\";", ([self.deviceType containsString:@"iPad3"] || [self.deviceType containsString:@"iPhone4"]) ? @"true" : @"false", self.deviceType]];
    
    // preload sounds
    [self performSelectorInBackground:@selector(preloadSounds) withObject:nil];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView {
    /*[UIView animateWithDuration:0.5 animations:^{
        _webView.alpha = 1;
    }];*/
    _webView.alpha = 1;
}

#pragma mark - ads

-(void)showAd{
    self.interstitialPresentationPolicy = ADInterstitialPresentationPolicyManual;
    BOOL canPresent = [self requestInterstitialAdPresentation];
    NSLog(@"Presenting ad: %@", canPresent ? @"true" : @"false");
}

#pragma mark - sfx

-(void)preloadSounds {
    NSString* dir = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"sfx"];
    NSArray* sfxs = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:nil];
    self.sfx = [[NSMutableDictionary alloc] init];
    for(NSString* name in sfxs){
        NSString* path = [dir stringByAppendingPathComponent:name];
        AVAudioPlayer* player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:path] error:nil];
        [_sfx setObject:[NSMutableArray arrayWithObject:player] forKey:[name stringByDeletingPathExtension]];
    }
}

-(void)loopSound:(NSString*)name volume:(CGFloat)volume{
    // stop loop with empty name
    if(!name.length){
        if(_currentlyLooping){
            if(_fadingIn || _fadingOut){
                [_currentlyLooping stop];
                [_currentlyLooping prepareToPlay];
            } else {
                _fadingOut = true;
                _loopingSoundTargetVolStep = MAX(0.05, _currentlyLooping.volume * 0.1);
                [self performSelector:@selector(fadeOut:) withObject:_currentlyLooping afterDelay:0];
            }
        }
        _currentlyLooping = nil;
        return;
    }
    
    // locate sound
    AVAudioPlayer* player = nil;
    NSMutableArray* arr = [_sfx objectForKey:name];
    if(!arr){
        NSLog(@"Sound %@ not found", name);
        return;
    }
    
    player = [arr objectAtIndex:0];
    
    // if sound already looping, and is the same, adjust volume
    if(player && player == _currentlyLooping){
        [_currentlyLooping setVolume:volume];
        return;
    }
    
    _currentlyLooping = player;
    [player setNumberOfLoops:-1];
    if(_fadingIn || _fadingOut){
        _fadingOut = _fadingIn = false;
        _loopingSoundTargetVol = volume;
        [player setVolume:volume];
        [player play];
    } else {
        _fadingIn = true;
        [player setVolume:0];
        _loopingSoundTargetVol = volume;
        _loopingSoundTargetVolStep = MAX(0.05, volume * 0.1);
        [player play];
        [self performSelector:@selector(fadeIn:) withObject:_currentlyLooping afterDelay:0];
    }
}

-(void)fadeIn:(AVAudioPlayer*)player {
    if(!_fadingIn) return;
    if (player.volume < _loopingSoundTargetVol) {
        player.volume = MIN(_loopingSoundTargetVol, player.volume + _loopingSoundTargetVolStep);
        [self performSelector:@selector(fadeIn:) withObject:player afterDelay:0.1];
    } else {
        _fadingIn = false;
    }
}

-(void)fadeOut:(AVAudioPlayer*)player {
    if(!_fadingOut) return;
    if (player.volume > 0.1) {
        player.volume = player.volume - _loopingSoundTargetVolStep;
        [self performSelector:@selector(fadeOut:) withObject:player afterDelay:0.1];
    } else {
        [player stop];
        //player.currentTime = 0;
        [player prepareToPlay];
        _fadingOut = false;
    }
}

-(void)playSound:(NSString*)name volume:(CGFloat)volume delay:(CGFloat)delay{
    //NSLog(@"play \"%@\", %f, after %f", name, volume, delay);

    AVAudioPlayer* player = nil;
    NSMutableArray* arr = [_sfx objectForKey:name];
    if(!arr){
        NSLog(@"Sound %@ not found", name);
        return;
    }
    // find one that's stopped
    for(AVAudioPlayer* p in arr){
        if(!p.isPlaying){
            player = p;
            break;
        }
    }
    if(!player){
        NSString* path = [[[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"sfx"] stringByAppendingPathComponent:name] stringByAppendingPathExtension:@"aiff"];
        player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:path] error:nil];
        [arr addObject:player];
    }
    [player setVolume:volume];
    if(delay > 0){
        [player playAtTime:player.deviceCurrentTime + delay];
    } else {
        [player play];
    }
}

@end
